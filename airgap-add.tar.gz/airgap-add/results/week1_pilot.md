# Week 1 pilot: does replay actually break the detector?

**Kill criterion.** Do not proceed with the project unless this shows a clear degradation.

## Protocol

1. Sample 100 clips: 50 bona fide (Common Voice Hindi), 50 synthetic (IndicSynth).
2. Score with pretrained AASIST. Record EER.
3. Play each clip through a laptop or Bluetooth speaker, record with a phone at ~1m in a
   normal room.
4. Score the re-recorded versions with the same model. Record EER.

## Results

| Condition | EER (%) |
|---|---|
| Clean digital | TBD |
| Re-recorded @ 1m | TBD |
| Degradation | TBD |

## Decision

- Degradation >= 8 points: PROCEED.
- Degradation < 3 points: STOP, re-scope.
- In between: investigate before committing.

Date run:
Decision:
Notes:
